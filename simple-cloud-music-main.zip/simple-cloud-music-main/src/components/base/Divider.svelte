<div class="diveder" />

<style>
  .diveder {
    margin: 5px auto;
    height: 1px;
    background-color: rgba(197, 197, 197, 0.3);
  }
</style>
